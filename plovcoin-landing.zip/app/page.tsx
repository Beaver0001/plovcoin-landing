import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Shield, Zap, Users, TrendingUp, Lock, Globe, Coins } from "lucide-react"
import Link from "next/link"

export default function PlovcoinLanding() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="px-4 lg:px-6 h-16 flex items-center border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <Link href="/" className="flex items-center justify-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
            <Coins className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Plovcoin
          </span>
        </Link>
        <nav className="ml-auto flex gap-6">
          <Link href="#features" className="text-sm font-medium hover:text-blue-600 transition-colors">
            Features
          </Link>
          <Link href="#about" className="text-sm font-medium hover:text-blue-600 transition-colors">
            About
          </Link>
          <Link href="#roadmap" className="text-sm font-medium hover:text-blue-600 transition-colors">
            Roadmap
          </Link>
          <Link href="#community" className="text-sm font-medium hover:text-blue-600 transition-colors">
            Community
          </Link>
        </nav>
        <div className="ml-6 flex gap-2">
          <Button variant="outline" size="sm">
            Whitepaper
          </Button>
          <Button
            size="sm"
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            Get Started
          </Button>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="flex flex-col items-center space-y-8 text-center">
              <Badge variant="secondary" className="px-4 py-2 text-sm font-medium">
                🚀 Now Live on Mainnet
              </Badge>

              <div className="space-y-4 max-w-4xl">
                <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl bg-gradient-to-r from-blue-600 via-purple-600 to-blue-800 bg-clip-text text-transparent">
                  The Future of Digital Currency is Here
                </h1>
                <p className="mx-auto max-w-2xl text-lg text-muted-foreground md:text-xl">
                  Plovcoin revolutionizes digital transactions with lightning-fast speeds, minimal fees, and
                  uncompromising security. Join the next generation of decentralized finance.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 w-full max-w-md">
                <Button
                  size="lg"
                  className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  Buy Plovcoin
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
                <Button size="lg" variant="outline" className="flex-1">
                  Learn More
                </Button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 pt-8 w-full max-w-2xl">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">$2.47</div>
                  <div className="text-sm text-muted-foreground">Current Price</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">+24.5%</div>
                  <div className="text-sm text-muted-foreground">24h Change</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">$847M</div>
                  <div className="text-sm text-muted-foreground">Market Cap</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="w-full py-12 md:py-24 lg:py-32 bg-white">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="text-center space-y-4 mb-12">
              <Badge variant="outline" className="px-3 py-1">
                Features
              </Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Why Choose Plovcoin?</h2>
              <p className="mx-auto max-w-2xl text-muted-foreground md:text-lg">
                Built with cutting-edge technology to deliver the best digital currency experience
              </p>
            </div>

            <div className="grid gap-6 lg:grid-cols-3 lg:gap-8">
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6 space-y-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Zap className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-bold">Lightning Fast</h3>
                  <p className="text-muted-foreground">
                    Process transactions in under 3 seconds with our advanced blockchain technology and optimized
                    consensus mechanism.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6 space-y-4">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <Shield className="w-6 h-6 text-green-600" />
                  </div>
                  <h3 className="text-xl font-bold">Ultra Secure</h3>
                  <p className="text-muted-foreground">
                    Military-grade encryption and multi-layer security protocols ensure your assets are always
                    protected.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6 space-y-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3 className="text-xl font-bold">Low Fees</h3>
                  <p className="text-muted-foreground">
                    Enjoy minimal transaction fees, typically under $0.01, making micro-transactions economically
                    viable.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6 space-y-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <Globe className="w-6 h-6 text-orange-600" />
                  </div>
                  <h3 className="text-xl font-bold">Global Access</h3>
                  <p className="text-muted-foreground">
                    Send and receive payments anywhere in the world, 24/7, without traditional banking limitations.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6 space-y-4">
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <Lock className="w-6 h-6 text-red-600" />
                  </div>
                  <h3 className="text-xl font-bold">Decentralized</h3>
                  <p className="text-muted-foreground">
                    No central authority controls Plovcoin. It's governed by the community through democratic consensus.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6 space-y-4">
                  <div className="w-12 h-12 bg-cyan-100 rounded-lg flex items-center justify-center">
                    <Users className="w-6 h-6 text-cyan-600" />
                  </div>
                  <h3 className="text-xl font-bold">Community Driven</h3>
                  <p className="text-muted-foreground">
                    Join a thriving community of developers, investors, and enthusiasts building the future together.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-600 to-purple-600">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4 text-center text-white">
              <div className="space-y-2">
                <div className="text-3xl font-bold">1M+</div>
                <div className="text-blue-100">Active Wallets</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold">50M+</div>
                <div className="text-blue-100">Transactions</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold">99.9%</div>
                <div className="text-blue-100">Uptime</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold">150+</div>
                <div className="text-blue-100">Countries</div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-slate-50">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="flex flex-col items-center space-y-8 text-center">
              <div className="space-y-4 max-w-2xl">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Ready to Join the Revolution?
                </h2>
                <p className="text-muted-foreground md:text-lg">
                  Start your journey with Plovcoin today. Buy, trade, and build on the most advanced digital currency
                  platform.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  Get Started Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
                <Button size="lg" variant="outline">
                  Download Wallet
                </Button>
              </div>

              <div className="text-sm text-muted-foreground">
                Available on all major exchanges • Fully audited smart contracts
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="w-full py-6 bg-white border-t">
        <div className="container px-4 md:px-6 mx-auto">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                <Coins className="w-4 h-4 text-white" />
              </div>
              <span className="font-semibold">Plovcoin</span>
            </div>
            <div className="flex gap-6 text-sm text-muted-foreground">
              <Link href="#" className="hover:text-blue-600 transition-colors">
                Privacy
              </Link>
              <Link href="#" className="hover:text-blue-600 transition-colors">
                Terms
              </Link>
              <Link href="#" className="hover:text-blue-600 transition-colors">
                Support
              </Link>
              <Link href="#" className="hover:text-blue-600 transition-colors">
                Contact
              </Link>
            </div>
            <div className="text-sm text-muted-foreground">© 2024 Plovcoin. All rights reserved.</div>
          </div>
        </div>
      </footer>
    </div>
  )
}
